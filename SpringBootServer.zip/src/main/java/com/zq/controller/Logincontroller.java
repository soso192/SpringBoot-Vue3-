package com.zq.controller;

import com.zq.pojo.User;
import com.zq.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/login")
public class Logincontroller {
    @Autowired LoginService loginService;
    @RequestMapping("/userlogin")
    @ResponseBody
    public String login(@RequestBody User user, HttpSession session){
        boolean b = loginService.UserisExsit(user);
        if(b){
            User user1 = loginService.GetUser(user);
            if(user1.getPassWord().equals(user.getPassWord())){
                System.out.println("*********"+user1);
                User user2 = new User();
                user2.setUserName("zhangsan");
                user2.setPassWord("123456");
                session.setAttribute("userlogin",user2);
                return "yes";
            }else{

                return "密码错误"; // 返回登录页面并显示错误消息
            }
        }else {

            return "没有该账号"; // 返回登录页面并显示错误消息
        }
    }
@RequestMapping("/hello")
    public String hello(){
        System.out.println("llllllllllllllllllll");
        return "";
}
}
