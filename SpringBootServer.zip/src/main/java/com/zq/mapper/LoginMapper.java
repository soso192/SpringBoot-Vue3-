package com.zq.mapper;

import com.zq.pojo.User;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
public interface LoginMapper {
    boolean UserIsExsit(User user);
    User GetUser(User user);
}
