package com.zq.mapper;

import com.zq.pojo.Book;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;
@Mapper
public interface BookMapper {
    List<Book>listBook();
    int deletebook(int id);
    int addbook(Book book);
    Book getbookbyid(int id);
    int updatebook(Book book);
    int borrowbook(int id);
}
