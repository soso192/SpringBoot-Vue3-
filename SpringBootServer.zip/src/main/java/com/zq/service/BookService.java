package com.zq.service;

import com.zq.pojo.Book;

import java.util.List;

public interface BookService {
    List<Book> list();
   int deletebook(int id);
    int addbook(Book book);
    Book bookbyid(int id);
    int updatebook(Book book);
    int borrowbook(int id);
}
