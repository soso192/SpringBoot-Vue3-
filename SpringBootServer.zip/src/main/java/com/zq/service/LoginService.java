package com.zq.service;

import com.zq.pojo.User;

public interface LoginService {
    boolean UserisExsit(User user);
    User GetUser(User user);
}
