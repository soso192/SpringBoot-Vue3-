package com.zq.service.impl;


import com.zq.mapper.BookMapper;
import com.zq.pojo.Book;
import com.zq.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookServiceImpl implements BookService {

@Autowired
   private BookMapper bookMapper;
    public List<Book> list() {
        List<Book> list = bookMapper.listBook();
        return list;
    }


    public int deletebook(int id){
        int h = bookMapper.deletebook(id);
        return h;
    }

    public int addbook(Book book){
        int h =bookMapper.addbook(book);
        return  h;
    }

    public Book bookbyid(int id) {
        Book book = bookMapper.getbookbyid(id);
        return book;
    }


    public int updatebook(Book book) {
        int h = bookMapper.updatebook(book);
        return h;
    }

    @Override
    public int borrowbook(int id) {
        int i = bookMapper.borrowbook(id);
        return  i;
    }
}
