package com.zq.service.impl;

import com.zq.mapper.LoginMapper;
import com.zq.pojo.User;
import com.zq.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LoginServiceImpl implements LoginService {
    @Autowired
    private LoginMapper loginMapper;

    @Override
    public boolean UserisExsit(User user) {
        boolean b = loginMapper.UserIsExsit(user);
        return b;
    }

    @Override
    public User GetUser(User user) {
        User user1 = loginMapper.GetUser(user);
        return user1;
    }
}
